# تحديث مشروعك (النسخة 1.1.1): المايك 🎤 وGoogle Translate 🌐

## ⭐ أسهل طريق
بدل ما تعدّل مشروعك القديم، افتح مجلد `lujain-android` (من ملف `lujain-android-play.zip`) بـ Android Studio.
- اسم الحزمة فيه هو نفسه اسم حزمة تطبيقك: `com.bequeen.lujain`.
- وقّعه بنفس مفتاح Be Queen LLC، من **Build → Generate Signed App Bundle / APK**.
- كل الإصلاحات جاهزة فيه. هيك بتخلص من مشاكل التركيب كلها.

إذا بدك تكمّل بمشروعك القديم، اتبع الخطوات تحت.

## ليش المايك كان عم يرجع لمايك الكيبورد؟
- ملف `AndroidManifest.xml` بالنسخة القديمة ما فيه قسم `<queries>`. بدونه، أندرويد 11 وأحدث بيخبّي خدمة التعرّف على الكلام عن التطبيق، فالمايك بيفشل والصفحة القديمة كانت تتحوّل لمايك الكيبورد.
- إذا بعد التحديث بيطلعلك «طبقة المايك مش موصولة»، معناها إنه `LujainSpeech` مش مضاف قبل `loadUrl`.
- لتتأكد إنه النسخة الجديدة هي اللي شغّالة، روح على ⚙️ الإعدادات. تحت لازم يكون مكتوب `v1.1.1 · app ✅`.

## ١. بدّل صفحة التطبيق
- بدّل `assets/lujain.html` بالملف الجديد.
- شو تغيّر فيه:
  - المايك ما عاد يعلق على «مايك الكيبورد».
  - إذا صار خطأ، بيطلع شرح واضح وزر «افتح إعدادات التطبيق».
  - صار في «🎤 فحص المايك» بـ ⚙️ الإعدادات.

## ٢. المايك 🎤 (هاد الإصلاح الأساسي)
1. حط `LujainSpeechBridge.kt` جنب `MainActivity.kt`.
   - إذا اسم الحزمة عندك مش `com.bequeen.lujain`، غيّر أول سطر بالملف.
2. امسح كلاس `LujainSpeech` القديم، وامسح سكربت المايك القديم إذا كان عندك واحد.
3. بـ `MainActivity`:
   - عرّف `private lateinit var speech: LujainSpeechBridge`.
   - جوّا `onCreate`، **قبل** `loadUrl(...)`، حط هالأسطر الثلاث:
     ```kotlin
     speech = LujainSpeechBridge(this, webView)
     webView.addJavascriptInterface(speech, "LujainSpeech")
     speech.requestPermissionOnce()   // 👈 بيطلب إذن المايك مرة وحدة بعد التثبيت
     ```
   - بـ `onPause` وبـ `onDestroy` ضيف `speech.destroy()`.
4. بملف `AndroidManifest.xml`، تأكد إنه فيه:
   ```xml
   <uses-permission android:name="android.permission.RECORD_AUDIO" />
   ```
   وفيه كمان قسم `<queries>` من ملف `AndroidManifest-snippet.xml`.

> ⚠️ لازم `MainActivity` يكون `AppCompatActivity` أو `ComponentActivity`. ولازم تعمل الجسر جوّا `onCreate` نفسه، مش بعدين، وإلا التطبيق بيطفي.

### كيف بيشتغل الإذن
- **أول مرة بتفتح التطبيق بعد التثبيت:** بيطلع طلب أندرويد «السماح لـ لجين بتسجيل الصوت؟». بيطلع مرة وحدة بس.
- **إذا المستخدم رفض:** التطبيق بيرجع يسأله لما يضغط على زر مايك.
  - إذا رفض مرتين، أندرويد نفسه بيوقّف السؤال. وقتها التطبيق بيفرجيه زر «افتح إعدادات التطبيق» ليسمح من هونيك.

## ٣. الصوت 🔊 (إذا لسّا ما عملته)
- حط `TtsBridge.kt` جنب `MainActivity.kt`.
- بـ `MainActivity`، **قبل** `loadUrl(...)` ضيف:
  ```kotlin
  tts = TtsBridge(this, webView)
  webView.addJavascriptInterface(tts, "LujainTTS")
  ```
- عرّف `private lateinit var tts: TtsBridge`.
- بـ `onPause` ضيف `tts.stopFromNative()`، وبـ `onDestroy` ضيف `tts.destroy()`.

## ٤. شيل Gemma (إذا لسّا ما عملته)
- امسح `LujainBrain.kt` و`ModelDownloader.kt`، وامسح كل سطر بيذكرهم بـ `MainActivity`.
- شيل سطر `litertlm-android` من `build.gradle`.
- شيل سطرين `uses-native-library` من الـ Manifest.

## بعدين
- زيد `versionCode` (مثلاً لـ 3) وخلّي `versionName` = `1.1.1`.
- ابنِ بـ Android Studio، وبعدها bundletool متل ما عملت.
- **للتجربة:**
  - امسح التطبيق القديم من الموبايل أول، لحتى يطلع طلب الإذن متل مستخدم جديد.
  - بعدين روح على ⚙️ ← «🎤 افحص» وقول Hello.
