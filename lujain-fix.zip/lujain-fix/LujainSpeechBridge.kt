package com.bequeen.lujain

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Microphone for the Lujain WebView (exposed to JavaScript as "LujainSpeech").
 *
 * Replaces the old LujainSpeech class. Same JavaScript contract:
 *   LujainSpeech.startListen(id, lang, interim, continuous)
 *   LujainSpeech.stopListen(id)
 *   -> window.__lujainSpeechEvent(id, type, payloadJson)   type = start | partial | final | error | end
 * Extra helpers used by the in-app mic check:
 *   LujainSpeech.hasPermission(), LujainSpeech.isAvailable(), LujainSpeech.openSettings()
 *
 * Fixes the usual reasons the mic stays silent in a WebView app:
 *   1. asks for the RECORD_AUDIO permission at runtime (Android 6+),
 *   2. runs SpeechRecognizer on the main thread (JS calls arrive on a background thread),
 *   3. falls back to the on-device recognizer when no recognition service is bound (Android 13+),
 *   4. reports clear error codes to the page instead of failing silently.
 *
 * MUST be created in onCreate (before the activity starts), and added BEFORE webView.loadUrl(...):
 *   speech = LujainSpeechBridge(this, webView)
 *   webView.addJavascriptInterface(speech, "LujainSpeech")
 *   speech.requestPermissionOnce()      // asks for the mic once, right after install
 * Also add to AndroidManifest.xml (inside <manifest>):
 *   <uses-permission android:name="android.permission.RECORD_AUDIO" />
 *   <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>
 */
class LujainSpeechBridge(private val activity: ComponentActivity, private val webView: WebView) {

    private var recognizer: SpeechRecognizer? = null
    private var curId = ""
    private var lang = "en-US"
    private var continuous = false
    private var active = false
    private var pending: (() -> Unit)? = null

    // Registered in the constructor, so the object must be created in onCreate.
    private val permissionLauncher = activity.registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val go = pending ?: return@registerForActivityResult   // first-launch request: nothing waiting
        pending = null
        if (granted) go() else { emit(curId, "error", "not-allowed"); emit(curId, "end") }
    }

    /**
     * Asks for the microphone ONE time, on the first launch after install.
     * Call it in onCreate right after creating this bridge. If the user says no,
     * the app asks again only when they tap a mic button (Android itself stops
     * showing the dialog after two refusals; the page then offers "Open settings").
     */
    fun requestPermissionOnce() {
        val prefs = activity.getSharedPreferences("lujain", android.content.Context.MODE_PRIVATE)
        if (prefs.getBoolean("mic_asked", false) || hasPermission()) return
        prefs.edit().putBoolean("mic_asked", true).apply()
        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    @JavascriptInterface
    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    @JavascriptInterface
    fun isAvailable(): Boolean =
        SpeechRecognizer.isRecognitionAvailable(activity) ||
            (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(activity))

    @JavascriptInterface
    fun openSettings() {
        activity.runOnUiThread {
            activity.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", activity.packageName, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    @JavascriptInterface
    fun startListen(id: String, lang: String, interim: Boolean, continuous: Boolean) {
        activity.runOnUiThread {
            stopInternal(sendEnd = true)
            curId = id
            this.lang = lang.ifBlank { "en-US" }
            this.continuous = continuous
            val go = {
                if (!isAvailable()) { emit(id, "error", "service-not-allowed"); emit(id, "end") }
                else { active = true; listen() }
            }
            if (hasPermission()) go() else { pending = go; permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        }
    }

    @JavascriptInterface
    fun stopListen(id: String) {
        activity.runOnUiThread {
            if (id != curId) return@runOnUiThread
            active = false
            recognizer?.stopListening()   // onResults / onError will follow and send "end"
        }
    }

    /** Call from Activity.onPause and onDestroy. */
    fun destroy() {
        activity.runOnUiThread { stopInternal(sendEnd = true); recognizer?.destroy(); recognizer = null }
    }

    private fun stopInternal(sendEnd: Boolean) {
        if (active || recognizer != null) {
            val wasActive = active
            active = false
            runCatching { recognizer?.cancel() }
            if (sendEnd && wasActive) emit(curId, "end")
        }
    }

    private fun createRecognizer(): SpeechRecognizer =
        if (!SpeechRecognizer.isRecognitionAvailable(activity) && Build.VERSION.SDK_INT >= 33 &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(activity)
        ) SpeechRecognizer.createOnDeviceSpeechRecognizer(activity)
        else SpeechRecognizer.createSpeechRecognizer(activity)

    private fun listen() {
        recognizer?.destroy()
        recognizer = createRecognizer().also { it.setRecognitionListener(listener) }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, activity.packageName)
        try { recognizer?.startListening(intent) }
        catch (t: Throwable) { active = false; emit(curId, "error", "aborted"); emit(curId, "end") }
    }

    private fun afterPhrase() {
        if (active && continuous) webView.postDelayed({ if (active) listen() }, 150)
        else { active = false; emit(curId, "end") }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = emit(curId, "start")
        override fun onPartialResults(partial: Bundle?) {
            val t = partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isNotBlank()) emit(curId, "partial", text = t)
        }
        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isNotBlank()) emit(curId, "final", text = t)
            afterPhrase()
        }
        override fun onError(error: Int) {
            val code = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER, SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> "network"
                SpeechRecognizer.ERROR_AUDIO -> "audio-capture"
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "language-not-supported"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "busy"
                SpeechRecognizer.ERROR_CLIENT -> return          // follows cancel(); "end" was already sent
                else -> "aborted"
            }
            if (code == "no-speech" && active && continuous) { afterPhrase(); return }
            active = false
            emit(curId, "error", code)
            emit(curId, "end")
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun emit(id: String, type: String, error: String? = null, text: String? = null) {
        val payload = JSONObject().apply { if (error != null) put("error", error); if (text != null) put("text", text) }.toString()
        val js = "window.__lujainSpeechEvent && window.__lujainSpeechEvent(${JSONObject.quote(id)},${JSONObject.quote(type)},${JSONObject.quote(payload)})"
        webView.post { webView.evaluateJavascript(js, null) }
    }
}
